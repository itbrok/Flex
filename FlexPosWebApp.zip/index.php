<?php

include_once 'config.php'; // Include the config file to get the default configurations


/*  ----- Check If Flex Is Installed -----  */
if($flex["installed"] == false) {
    if(file_exists("install/install.php")) {
        include_once "install/install.php";
    }else{
        echo "<div>Flex is not Installed</div>";
    }
    exit;
}


function errorMsg() {
    if (!checkLogin()) {
        echo json_encode(["ok" => false, "msg" => "يجب تسجيل الدخول اولا", "code" => 4]);
        exit();
    }
}

include("functions.php");
if (@$_POST) {
    if (@$_POST["barcode"]) {
        errorMsg();
        $data = getProductByBarcode($_POST["barcode"]);
        if ($data != false) {
            echo json_encode(["ok" => true, $data]);
        } else {
            echo $data;
        }
    } elseif (@$_POST["getwholesale_price"]) {
        errorMsg();
        if (getSittings("wholesale_password") == $_POST["getwholesale_price"]["password"]) {
            $data = getProductByBarcode($_POST["getwholesale_price"]["barcode"]);
            if ($data != false) {
                echo json_encode(["ok" => true, $data["wholesale_price"]]);
            } else {
                echo $data;
            }
        } else {
            echo json_encode(["ok" => false, "msg" => "كلمة المرور غير صحيحة"]);
        }
    } elseif (@$_POST["defult_product_img"]) {
        errorMsg();
        $data = getSittings("defult_product_img");
        if ($data != false) {
            echo json_encode(["ok" => true, $data]);
        } else {
            echo json_encode(["ok" => false, "msg" => "حدث خطا اثناء تحميل صورة المنتج"]);
        }
    } elseif (@$_POST["search"]) {  //Search
        errorMsg();
        $data = getProductBySearch($_POST["search"]);
        if ($data != false) {
            echo json_encode(["ok" => true, $data]);
        } else {
            echo $data;
        }
    } elseif (strlen(@$_POST["unit"] ?? '') > 0) {  //Unit
        errorMsg();
        $data = getUnitByID($_POST["unit"]);
        if ($data != false) {
            echo json_encode(["ok" => true, $data]);
        } else {
            echo $data;
        }
    } elseif (strlen(@$_POST["getclass"] ?? '') > 0) {  //Class
        errorMsg();
        $data = getClassByID($_POST["getclass"]);
        if ($data != false) {
            echo json_encode(["ok" => true, $data]);
        } else {
            echo $data;
        }
    } elseif (strlen(@$_POST["canIuseThisOrder"] ?? '') > 0) {  //searchOrder
        errorMsg();
        $data = getOrder($_POST["canIuseThisOrder"]);
        if (@$data != false) {
            echo json_encode(["ok" => false]);
        } else {
            echo json_encode(["ok" => true]);
        }
    } elseif (strlen(@$_POST["getorder"] ?? '') > 0) {  //get Order data
        errorMsg();
        $data = getOrder($_POST["getorder"]);
        if (@$data != false) {
            echo json_encode(["ok" => true, $data]);
        } else {
            echo json_encode(["ok" => false]);
        }
    } elseif (@$_POST["saveOrder"]) {  //saveOrder
        errorMsg();
        $data = saveOrder($_POST["saveOrder"]);
        if (@$data != false) {
            echo json_encode(["ok" => true]);
        } else {
            echo json_encode(["ok" => false]);
        }
    } elseif (@$_POST["getUnFinishedOrders"]) {  //unfinished Orders
        errorMsg();
        $data = getUnFinishedOrders();
        if (@$data != false) {
            echo json_encode(["ok" => true, $data]);
        } else {
            echo json_encode(["ok" => false, "msg" => "لاتوجد فواتير معلقه"]);
        }
    } elseif (@$_POST["getOrderDetails"]) {  // Orders Details
        errorMsg();
        $data = getOrderDetails($_POST["getOrderDetails"], 0);
        if (@$data != false) {
            echo json_encode(["ok" => true, $data]);
        } else {
            echo json_encode(["ok" => false, "msg" => "لا يوجد مواد متعلقه بهذا الطلب"]);
        }
    } elseif (@$_POST["getallOrders"]) {  //get Orders for admin
        errorMsg();
        if (checkRole($_SESSION["user_id"], "admin_panel")) {
            $data = getOrders($_POST["getallOrders"]);
            if (@$data != false) {
                echo json_encode(["ok" => true, $data]);
            } else {
                echo json_encode(["ok" => false, "msg" => "لا توجد فواتير"]);
            }
        } else {
            echo json_encode(["ok" => false, "msg" => "غير مصرح"]);
        }
    } elseif (@$_POST["getOrderDetailsForAdmin"]) {  // Get Orders Details For Admin
        errorMsg();
        if (checkRole($_SESSION["user_id"], "admin_panel")) {
            $data = getOrderDetails($_POST["getOrderDetailsForAdmin"]);
            if (@$data != false) {
                echo json_encode(["ok" => true, $data]);
            } else {
                echo json_encode(["ok" => false, "msg" => "لا يوجد مواد متعلقه بهذا الطلب"]);
            }
        } else {
            echo json_encode(["ok" => false, "msg" => "غير مصرح"]);
        }
    } elseif (key_exists("newconsumer",$_POST)) {  //newconsumer
        errorMsg();
        $data = addNewConsumer($_POST["name"], @$_POST["phone_number"], @$_POST["address"], @$_POST["notes"]);
        if (@$data["ok"] != false) {
            echo json_encode(["ok" => true, $data]);
        } else {
            echo json_encode($data);
        }
    } elseif (key_exists("updateconsumer",$_POST)) {  //update Consumer
        errorMsg();
        $data = updateConsumer($_POST["id"], @$_POST["name"], @$_POST["phone_number"], @$_POST["address"], @$_POST["notes"]);
        if (@$data["ok"] != false) {
            echo json_encode(["ok" => true, $data]);
        } else {
            echo json_encode($data);
        }
    } elseif (strlen(@$_POST["searchconsumer"] ?? '') > 0) {  //search consumer
        errorMsg();
        $data = getConsumer($_POST["searchconsumer"]);
        if ($data) {
            echo json_encode(["ok" => true, $data]);
        } else {
            echo json_encode(["ok" => false]);
        }
    } elseif (strlen(@$_POST["searchConsumerWithAddBy"] ?? '') > 0) {  //search consumer
        errorMsg();
        $data = getConsumerWithAddBy($_POST["searchConsumerWithAddBy"]);
        if ($data) {
            echo json_encode(["ok" => true, $data]);
        } else {
            echo json_encode(["ok" => false]);
        }
    } elseif (@$_POST["getconsumer"]) {  //get one consumer data
        errorMsg();
        $data = getConsumer($_POST["getconsumer"], false, true);
        if ($data) {
            echo json_encode(["ok" => true, $data]);
        } else {
            echo json_encode(["ok" => false]);
        }
    } elseif (@$_POST["getLastAddedClients"]) {  //get last inserted clients
        errorMsg();
        $data = getLastAddedClients();
        if ($data) {
            echo json_encode(["ok" => true, $data]);
        } else {
            echo json_encode(["ok" => false]);
        }
    } elseif (@$_POST["getdebtvalue"]) {  //get consumer's debt value
        errorMsg();
        $data = getDebtValue($_POST["getdebtvalue"]);
        if ($data) {
            echo json_encode(["ok" => true, $data]);
        } else {
            echo json_encode(["ok" => false, "msg" => "هذا العميل لاتوجد عليه ديون سابقه"]);
        }
    } elseif (@$_POST["paydebt"]) {  //pay consumer's debt
        errorMsg();
        $data = payDebt($_POST["paydebt"]["consumer_id"], $_POST["paydebt"]["value"]);
        if ($data) {
            echo json_encode(["ok" => true]);
        } else {
            echo json_encode(["ok" => false]);
        }
    } elseif (@$_POST["change_my_password"]) {  //pay consumer's debt
        errorMsg();
        $data = change_my_pass($_POST["change_my_password"]);
        if ($data) {
            echo json_encode(["ok" => true]);
        } else {
            echo json_encode(["ok" => false]);
        }
    } elseif (@$_POST["iqd"]) {  //iqd
        errorMsg();
        $data = getIQD();
        if ($data != false) {
            echo json_encode(["ok" => true, $data]);
        } else {
            echo $data;
        }
    } elseif (@$_POST['login']) {  //Login
        if (checkLogin()) {
            echo json_encode(["ok" => true, "msg" => "مسجل مسبقا", "code" => 2]);
            exit();
        }
        if (empty(@$_POST['username']) || empty(@$_POST['password'])) {
            echo json_encode(["ok" => false, "msg" => "يجب ادخال اسم المستخدم وكلمة المرور", "code" => 3]);
            exit();
        }
        $resp = getUser(@$_POST['username'], @$_POST['password']);
        if ($resp != false) {
            $_SESSION["user_id"] = $resp["id"];
            $_SESSION['password'] = $resp['password'];
            echo json_encode(["ok" => true]);
        } else {
            echo json_encode(["ok" => false, "msg" => "خطأ في تسجيل الدخول", "code" => 1]);
        }
    } elseif (@$_POST['getProductsCount'] == 1) {
        errorMsg();
        if (checkRole($_SESSION["user_id"], "admin_panel")) { // done
            $data = getProductsCount();
            if ($data != false) {
                echo json_encode(["ok" => true, $data]);
            } else {
                echo json_encode(["ok" => false, "msg" => "لاتوجد بيانات"]);
            }
        } else {
            echo json_encode(["ok" => false, "msg" => "غير مصرح"]);
        }
    } elseif (@$_POST['getClientsCount'] == 1) {
        if (checkRole($_SESSION["user_id"], "admin_panel")) { // done
            $data = getClientsCount();
            if ($data != false) {
                echo json_encode(["ok" => true, $data]);
            } else {
                echo json_encode(["ok" => false, "msg" => "لاتوجد بيانات"]);
            }
        } else {
            echo json_encode(["ok" => false, "msg" => "غير مصرح"]);
        }
    } elseif (@$_POST['getClientsList']) {  // get client list
        errorMsg();
        if (checkRole($_SESSION["user_id"], "admin_panel")) {
            $data = getClients(@$_POST['getClientsList']);
            if ($data != false) {
                echo json_encode(["ok" => true, $data]);
            } else {
                echo json_encode(["ok" => false, "msg" => "لاتوجد بيانات"]);
            }
        } else {
            echo json_encode(["ok" => false, "msg" => "غير مصرح"]);
        }
        
    } elseif (@$_POST['getUsersList']) {  // get users list
        errorMsg();
        if (checkRole($_SESSION["user_id"], "admin_panel")) {
            $data = getUsers(@$_POST['getUsersList']);
            if ($data != false) {
                echo json_encode(["ok" => true, $data]);
            } else {
                echo json_encode(["ok" => false, "msg" => "لاتوجد بيانات"]);
            }
        } else {
            echo json_encode(["ok" => false, "msg" => "غير مصرح"]);
        }
        
    } elseif (@$_POST['getproductsList']) {  // get products List
        errorMsg();
        if (checkRole($_SESSION["user_id"], "admin_panel")) {
            $data = getProductsList(@$_POST['getproductsList']);
            if ($data != false) {
                echo json_encode(["ok" => true, $data]);
            } else {
                echo json_encode(["ok" => false, "msg" => "لاتوجد بيانات"]);
            }
        } else {
            echo json_encode(["ok" => false, "msg" => "غير مصرح"]);
        }
        
    } elseif (@$_POST['getUserData']) {  // get one user data
        errorMsg();
        if (checkRole($_SESSION["user_id"], "admin_panel")) {
            $data = getUserByID(@$_POST['getUserData']);
            if ($data != false) {
                echo json_encode(["ok" => true, $data]);
            } else {
                echo json_encode(["ok" => false, "msg" => "لاتوجد بيانات"]);
            }
        } else {
            echo json_encode(["ok" => false, "msg" => "غير مصرح"]);
        }
        
    } elseif (@$_POST['newUser']) {  // add new user
        errorMsg();
        if (checkRole($_SESSION["user_id"], "admin_panel")) {
            $data = addNewUser(@$_POST['username'], @$_POST['password'], @$_POST['name'], @$_POST['isAdmin']);
            if ($data != false) {
                echo json_encode($data);
            } else {
                echo json_encode(["ok" => false, "msg" => "لاتوجد بيانات"]);
            }
        } else {
            echo json_encode(["ok" => false, "msg" => "غير مصرح"]);
        }
        
    } elseif (@$_POST['updateUser']) {  // update user data
        errorMsg();
        if (checkRole($_SESSION["user_id"], "admin_panel")) {
            $data = updateUserData(@$_POST['username'], @$_POST['password'], @$_POST['name'], @$_POST['id'], @$_POST['isAdmin']);
            if ($data != false) {
                echo json_encode($data);
            } else {
                echo json_encode(["ok" => false, "msg" => "لاتوجد بيانات"]);
            }
        } else {
            echo json_encode(["ok" => false, "msg" => "غير مصرح"]);
        }
    } elseif (@$_POST['getReceiptsCount'] == 1) {
        errorMsg();
        if (checkRole($_SESSION["user_id"], "admin_panel")) {
            $data = getReceiptsCount();
            if ($data != false) {
                echo json_encode(["ok" => true, $data]);
            } else {
                echo json_encode(["ok" => false, "msg" => "لاتوجد بيانات"]);
            }
        } else {
            echo json_encode(["ok" => false, "msg" => "غير مصرح"]);
        }
    } elseif (@$_POST['getUsersCount'] == 1) {
        errorMsg();
        if (checkRole($_SESSION["user_id"], "admin_panel")) {
            $data = getUsersCount();
            if ($data != false) {
                echo json_encode(["ok" => true, $data]);
            } else {
                echo json_encode(["ok" => false, "msg" => "لاتوجد بيانات"]);
            }
        } else {
            echo json_encode(["ok" => false, "msg" => "غير مصرح"]);
        }
    } elseif (@$_POST['getProductByID']) { // get Product By ID
        errorMsg();
        if (checkRole($_SESSION["user_id"], "admin_panel")) {
            $data = getProductByID($_POST['getProductByID']);
            if ($data != false) {
                echo json_encode(["ok" => true, $data]);
            } else {
                echo json_encode(["ok" => false, "msg" => "لاتوجد بيانات"]);
            }
        } else {
            echo json_encode(["ok" => false, "msg" => "غير مصرح"]);
        }
    } elseif (@$_POST['addNewProduct']) {  // add new product
        errorMsg();
        if (checkRole($_SESSION["user_id"], "admin_panel")) {
            $data = addNewProduct($_POST);
            if ($data != false) {
                echo json_encode($data);
            } else {
                echo json_encode(["ok" => false, "msg" => "لاتوجد بيانات"]);
            }
        } else {
            echo json_encode(["ok" => false, "msg" => "غير مصرح"]);
        }
    } elseif (@$_POST['updateproduct']) {  // update product
        errorMsg();
        if (checkRole($_SESSION["user_id"], "admin_panel")) {
            $data = updateProduct($_POST);
            if ($data != false) {
                echo json_encode($data);
            } else {
                echo json_encode(["ok" => false, "msg" => "لاتوجد بيانات"]);
            }
        } else {
            echo json_encode(["ok" => false, "msg" => "غير مصرح"]);
        }
    } elseif (@$_POST['deleteItem']) {  // delete items
        errorMsg();
        if (checkRole($_SESSION["user_id"], "admin_panel")) {
            $data = deleteItem($_POST['deleteItem'], @$_POST['id']);
            if ($data != false) {
                echo json_encode(["ok" => true, $data]);
            } else {
                echo json_encode(["ok" => false, "msg" => "لاتوجد بيانات"]);
            }
        } else {
            echo json_encode(["ok" => false, "msg" => "غير مصرح"]);
        }
    } elseif (@$_POST['addNewUnit']) {  // add New unit
        errorMsg();
        if (checkRole($_SESSION["user_id"], "admin_panel")) {
            $data = addNewUnit($_POST['type']);
            if ($data != false) {
                echo json_encode(["ok" => true, $data]);
            } else {
                echo json_encode(["ok" => false, "msg" => "لاتوجد بيانات"]);
            }
        } else {
            echo json_encode(["ok" => false, "msg" => "غير مصرح"]);
        }
    } elseif (@$_POST['addNewClass']) {  // add New class
        errorMsg();
        if (checkRole($_SESSION["user_id"], "admin_panel")) {
            $data = addNewClass($_POST['type']);
            if ($data != false) {
                echo json_encode(["ok" => true, $data]);
            } else {
                echo json_encode(["ok" => false, "msg" => "لاتوجد بيانات"]);
            }
        } else {
            echo json_encode(["ok" => false, "msg" => "غير مصرح"]);
        }
    } elseif (@$_POST['updateclass']) {  // update class
        errorMsg();
        if (checkRole($_SESSION["user_id"], "admin_panel")) {
            $data = updateClass($_POST['type'], $_POST['id']);
            if ($data != false) {
                echo json_encode(["ok" => true, $data]);
            } else {
                echo json_encode(["ok" => false, "msg" => "لاتوجد بيانات"]);
            }
        } else {
            echo json_encode(["ok" => false, "msg" => "غير مصرح"]);
        }
    } elseif (@$_POST['updateunit']) {  // update unit
        errorMsg();
        if (checkRole($_SESSION["user_id"], "admin_panel")) {
            $data = updateUnit($_POST['type'], $_POST['id']);
            if ($data != false) {
                echo json_encode(["ok" => true, $data]);
            } else {
                echo json_encode(["ok" => false, "msg" => "لاتوجد بيانات"]);
            }
        } else {
            echo json_encode(["ok" => false, "msg" => "غير مصرح"]);
        }
    } elseif (@$_POST['update_defult_product_img']) {  // update unit
        errorMsg();
        if (checkRole($_SESSION["user_id"], "admin_panel")) {
            $data = updateSetting("defult_product_img", $_POST['update_defult_product_img']);
            if ($data != false) {
                echo json_encode(["ok" => true, $data]);
            } else {
                echo json_encode(["ok" => false, "msg" => "لاتوجد بيانات"]);
            }
        } else {
            echo json_encode(["ok" => false, "msg" => "غير مصرح"]);
        }
    } elseif (@$_POST['change_wholesale_password']) {  // update unit
        errorMsg();
        if (checkRole($_SESSION["user_id"], "admin_panel")) {
            $data = updateSetting("wholesale_password", $_POST['change_wholesale_password']);
            if ($data != false) {
                echo json_encode(["ok" => true, $data]);
            } else {
                echo json_encode(["ok" => false, "msg" => "لاتوجد بيانات"]);
            }
        } else {
            echo json_encode(["ok" => false, "msg" => "غير مصرح"]);
        }
    } elseif (@$_POST['getunitsList']) {  // get unit list
        errorMsg();
        if (checkRole($_SESSION["user_id"], "admin_panel")) {
            $data = getUnitsList();
            if ($data != false) {
                echo json_encode(["ok" => true, $data]);
            } else {
                echo json_encode(["ok" => false, "msg" => "لاتوجد بيانات"]);
            }
        } else {
            echo json_encode(["ok" => false, "msg" => "غير مصرح"]);
        }
    } elseif (@$_POST['getclassList']) {  // get class list
        errorMsg();
        if (checkRole($_SESSION["user_id"], "admin_panel")) {
            $data = getClassesList();
            if ($data != false) {
                echo json_encode(["ok" => true, $data]);
            } else {
                echo json_encode(["ok" => false, "msg" => "لاتوجد بيانات"]);
            }
        } else {
            echo json_encode(["ok" => false, "msg" => "غير مصرح"]);
        }
    }  elseif (@$_POST['getnotifications']) {  // get notifications list (log class)
        errorMsg();
        if (checkRole($_SESSION["user_id"], "admin_panel")) {
            $data = getNotifications($_POST['getnotifications']);
            if ($data != false) {
                echo json_encode(["ok" => true, $data]);
            } else {
                echo json_encode(["ok" => false, "msg" => "لاتوجد بيانات"]);
            }
        } else {
            echo json_encode(["ok" => false, "msg" => "غير مصرح"]);
        }
    } elseif (@$_POST['getUnitesAndClass']) {  // get Unites And Classes As Json
        errorMsg();
        $data = getUnitesAndClass();
        if ($data != false) {
            echo json_encode(["ok" => true, $data]);
        } else {
            echo json_encode(["ok" => false, "msg" => "حدث خطأ"]);
        }
    } else { //END
        echo json_encode(["ok" => false, "msg" =>"لم يتم التعرف على الطلب", $_POST]);
    }
} else {
    if (checkLogin()) {

        if (@$_GET["logout"] == 1) {
            logout();
        } else {
            if (checkRole($_SESSION["user_id"], "admin_panel")) {
                $admin_panel = [
                    "analytics_panel"   => "assets/theme/analytics_panel.html",
                    "products_panel"    => "assets/theme/products_panel.html",
                    "settings_panel"    => "assets/theme/settings_panel.php",
                    "clients_panel"     => "assets/theme/clients_panel.html",
                    "salse_panel"       => "assets/theme/sales_panel.html",
                    "users_panel"       => "assets/theme/users_panel.html",
                    "class_panel"       => "assets/theme/class_panel.html",
                    "unit_panel"        => "assets/theme/unit_panel.html",
                    "product"           => "assets/theme/product.html",
                    "client"            => "assets/theme/client.html",
                    "class"             => "assets/theme/class.html",
                    "user"              => "assets/theme/user.html",
                    "unit"              => "assets/theme/unit.html",
                ];

                $requestedPage = @$_GET["p"];
                if (key_exists($requestedPage, $admin_panel)) {
                    $contant_body = $admin_panel[$requestedPage];
                } else {
                    $contant_body = $admin_panel["analytics_panel"];
                }
                include("assets/theme/admin_panel.php");
            } else {
                include("assets/theme/search.html");
            }
        }
    } else {
        if (@$_GET["getitemname"]) {
            $data = getProductByBarcode($_GET["getitemname"]);
            if ($data != false) {
                echo json_encode(["ok" => true, $data["name"]]);
            } else {
                echo $data;
            }
        } else {
            include("assets/theme/login.html");
        }
    }
}
