<?php
require_once 'config.php';
ob_start();
session_start();
header("Access-Control-Allow-Origin: *");
function logout() {
    session_destroy();
    header("Location:index.php");
    exit();
}

function checkLogin($logout = false) {
    if (!isset($_SESSION["user_id"])) {
        if ($logout) {
            logout();
        }
        return false;
    }
    return true;
}

function getProductByBarcode($barcode) {
    $conn = conn();
    $stmt = $conn->prepare("SELECT * FROM product WHERE barcode REGEXP ?");
    $stmt->bind_param("s", $barcode);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            if (is_array(json_decode($row["barcode"], true))) {
                $row["barcode"] = json_decode($row["barcode"], true)[0];
            }
            return $row;
        }
    }
    return false;
}

function getProductByID($id) {
    $conn = conn();
    $stmt = $conn->prepare("SELECT * FROM product WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            return $row;
        }
    }
    return false;
}

function getUnitesAndClass() {
    $u = getUnitsList();
    $c = getClassesList();
    $resp["unit"] = $u;
    $resp["class"] = $c;
    return $resp;
}

function getProductBySearch($barcode) {
    $conn = conn();
    $stmt = $conn->prepare("SELECT * FROM product WHERE barcode REGEXP ? or `name` LIKE ? or `number` LIKE ? ORDER BY `name` ASC");
    $likeVal = str_replace(" ", "%", "%" . $barcode . "%");
    $stmt->bind_param("sss", $barcode, $likeVal, $likeVal);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            if (is_array(json_decode($row["barcode"], true))) {
                $row["barcode"] = json_decode($row["barcode"], true)[0];
            }

            $rows[] = $row;
        }
        return $rows;
    }
    return false;
}

function getUnitByID($id) {
    $conn = conn();
    $stmt = $conn->prepare("SELECT `type` FROM unit WHERE id = ?");
    $stmt->bind_param("s", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            return $row["type"];
        }
    }
    return false;
}

function getMoneyPaid($clientId) {
    $conn = conn();
    $stmt = $conn->prepare("SELECT SUM(money_paid) AS `MoneyPaid` FROM debt WHERE consumer_id = ?");
    $stmt->bind_param("i", $clientId);
    if ($stmt->execute()) {
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                return $row["MoneyPaid"];
            }
        } else {
            return false;
        }
    } else {
        return false;
    }
}

function getPriceLeft($consumer_id) {
    $conn = conn();
    $stmt = $conn->prepare("SELECT SUM(price_left) AS `PriceLeft` FROM orders WHERE consumer_id = ?");
    $stmt->bind_param("i", $consumer_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            return $row["PriceLeft"];
        }
    }
    return false;
}

function getDebtValue($clientId) {
    $moneyPaid = getMoneyPaid($clientId);
    if ($moneyPaid == false) {
        $moneyPaid = 0;
    }
    $priceLeft = getPriceLeft($clientId);
    if ($priceLeft == false) {
        $priceLeft = 0;
    }
    return $moneyPaid - $priceLeft;
}

function payDebt($consumer_id, $val) {
    try {
        $conn = conn();
        $stmt = $conn->prepare("INSERT INTO `debt` (`employee_id`, `consumer_id`, `money_paid`) VALUES (?, ?, ?)");
        $stmt->bind_param("iid", $_SESSION["user_id"], $consumer_id, $val);
        $stmt->execute();
        return true;
    } catch (\Throwable $th) {

        return false;
    }
}

function getClassByID($id) {
    $conn = conn();
    $stmt = $conn->prepare("SELECT `type` FROM class WHERE id = ?");
    $stmt->bind_param("s", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            return $row["type"];
        }
    }
    return false;
}

function getSittings($var) {
    $conn = conn();
    $stmt = $conn->prepare("SELECT `value` FROM `sittings` WHERE variable = ?");
    $stmt->bind_param("s", $var);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            return $row["value"];
        }
    }
    return false;
}
function getIQD($iqd = "iq") {
    $conn = conn();
    $stmt = $conn->prepare("SELECT `val` FROM currency WHERE country = ?");
    $stmt->bind_param("s", $iqd);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            return $row;
        }
    }
    return false;
}

function getProductsCount() {
    $conn = conn();
    $stmt = $conn->prepare("SELECT COUNT(id) AS `ProductsCount` FROM `product`");
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            return $row["ProductsCount"] ?? 0;
        }
    }
    return false;
}

function getClientsCount() {
    $conn = conn();
    $stmt = $conn->prepare("SELECT COUNT(*) AS `ClientsCount` FROM `consumer`");
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            return $row["ClientsCount"] - 1 ?? 0;
        }
    }
    return false;
}

function getReceiptsCount() {
    $conn = conn();
    $stmt = $conn->prepare("SELECT COUNT(order_id) AS `ReceiptsCount` FROM `orders`");
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            return $row["ReceiptsCount"];
        }
    }
    return false;
}

function getUsersCount() {
    $conn = conn();
    $stmt = $conn->prepare("SELECT COUNT(id) AS `UsersCount` FROM `users`");
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            return $row["UsersCount"];
        }
    }
    return false;
}

function getUser($username, $password) {
    $conn = conn();
    $stmt = $conn->prepare("SELECT * FROM users WHERE `username` = ? AND `password` = ? LIMIT 1");
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            return $row;
        }
    }
    return false;
}

function getUserByID($id) {
    $conn = conn();
    $stmt = $conn->prepare("SELECT * FROM users WHERE `id` = ? LIMIT 1");
    $stmt->bind_param("s", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $row["isAdmin"] = checkRole($id, "admin_panel");
            return $row;
        }
    }
    return false;
}

function getUserByUserName($un) {
    $conn = conn();
    $stmt = $conn->prepare("SELECT * FROM users WHERE `username` = ? LIMIT 1");
    $stmt->bind_param("s", $un);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            return $row;
        }
    }
    return false;
}

function getUsers($limit) {
    try {
        $limit = ($limit - 1);
        $conn = conn();
        $stmt = $conn->prepare("SELECT x.resCount, c.id, c.name, c.username, c.date, u.name as addby, u.id as addbyid FROM users AS c , (select count(*) as resCount FROM users) AS x, users AS u WHERE c.added_by=u.id AND c.id != ? LIMIT ?, 10;");
        $stmt->bind_param("ii", $_SESSION["user_id"], $limit);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $rows[] = $row;
            }
            return $rows;
        }
    } catch (\Throwable $th) {
        file_put_contents("log.txt", file_get_contents("log.txt") . "\n" . $th);
        return false;
    }
}

function getproductsList($limit) {
    try {
        $limit = ($limit - 1);
        $conn = conn();
        $stmt = $conn->prepare("SELECT x.resCount, p.* FROM product AS p , (select count(*) as resCount FROM product) AS x LIMIT ?, 40");
        $stmt->bind_param("i", $limit);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $rows[] = $row;
            }
            return $rows;
        }
    } catch (\Throwable $th) {
        file_put_contents("log.txt", file_get_contents("log.txt") . "\n" . $th);
        return false;
    }
}

function getNotifications($limit) {
    try {
        $limit = ($limit - 1);
        $conn = conn();
        $stmt = $conn->prepare(
            "SELECT
            o.order_id,
            o.items_count,
            u.name AS userName,
            c.name AS clientName,
            o.total_price
            FROM `orders` AS o
            JOIN `users` AS u
            JOIN consumer AS c
            ON c.id = o.consumer_id
            AND u.id = o.employee_id
            WHERE o.date BETWEEN date_sub(now(),INTERVAL 1 DAY) and now()
            AND o.isitfinished = 1
            ORDER BY o.date ASC
            LIMIT ?, 40"
        );
        $stmt->bind_param("i", $limit);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $rows[] = $row;
            }
            return $rows;
        }
    } catch (\Throwable $th) {
        file_put_contents("log.txt", file_get_contents("log.txt") . "\n" . $th);
        return false;
    }
}

function checkRole($id, $role) {
    $conn = conn();
    $stmt = $conn->prepare("SELECT `role_value` FROM `role` WHERE `user_id` = ? AND `role_name` = ? LIMIT 1");
    $stmt->bind_param("ss", $id, $role);
    if ($stmt->execute()) {
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                return $row["role_value"] == 1;
            }
        }
    } else {
        return false;
    }
    return false;
}

function addRole($role_name, $role_value, $id) {
    $conn = conn();
    $stmt = $conn->prepare("INSERT INTO `role` (`role_name`, `role_value`, `user_id`) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $role_name, $role_value, $id);
    if ($stmt->execute()) {
        return true;
    } else {
        return false;
    }
    return false;
}

function updateRole($role_name, $role_value, $id) {
    $conn = conn();
    $stmt = $conn->prepare("UPDATE `role` SET `role_value` = ? WHERE `user_id` = ? AND `role_name` = ?");
    $stmt->bind_param("sss", $role_value, $id, $role_name);
    if ($stmt->execute()) {
        return true;
    } else {
        return false;
    }
    return false;
}

function getOrder($orderID) {
    $conn = conn();
    $stmt = $conn->prepare("SELECT * FROM orders WHERE `order_id` = ? LIMIT 1");
    $stmt->bind_param("s", $orderID);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            return $row;
        }
    }
    return false;
}

function getUnFinishedOrders() {
    try {
        $conn = conn();
        $stmt = $conn->prepare("SELECT * FROM orders WHERE `isitfinished` = 0");
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $rows[] = $row;
            }
            return $rows;
        }
    } catch (\Throwable $th) {
        file_put_contents("log.txt", file_get_contents("log.txt") . "\n" . $th);
        return false;
    }
}

function getClients($limit) {
    try {
        $limit = ($limit - 1);
        $conn = conn();
        $stmt = $conn->prepare("SELECT x.resCount, c.id, c.name, c.address, c.date, u.name as addby, u.id as addbyid FROM consumer AS c , (select count(*) -1 as resCount FROM consumer) AS x, users AS u WHERE c.added_by=u.id LIMIT ?, 10");
        $stmt->bind_param("i", $limit);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $rows[] = $row;
            }
            return $rows;
        }
    } catch (\Throwable $th) {
        file_put_contents("log.txt", file_get_contents("log.txt") . "\n" . $th);
        return false;
    }
}


function getOrders($limit) {
    try {
        $limit = ($limit - 1);
        $conn = conn();
        $stmt = $conn->prepare("SELECT x.resCount, o.* FROM orders AS o , (select count(*) as resCount FROM orders WHERE orders.isitfinished = 1) AS x WHERE o.isitfinished = 1 LIMIT ?, 10");
        $stmt->bind_param("i", $limit);
        if ($stmt->execute()) {
            $result = $stmt->get_result();
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $rows[] = $row;
                }
                return $rows;
            }
        } else {
            return false;
        }
    } catch (\Throwable $th) {
        file_put_contents("log.txt", file_get_contents("log.txt") . "\n" . $th);
        return false;
    }
}

function getOrderDetails($order_id) {
    try {
        $conn = conn();
        $stmt = $conn->prepare("SELECT * FROM order_detail WHERE `order_id` = ?");
        $stmt->bind_param("s", $order_id);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $rows[] = $row;
            }
            return $rows;
        }
    } catch (\Throwable $th) {
        file_put_contents("log.txt", file_get_contents("log.txt") . "\n" . $th);
        return false;
    }
}

function getLastAddedClients() {
    try {
        $conn = conn();
        $stmt = $conn->prepare("SELECT c.id, c.name, c.address, c.date, u.name as addby, u.id as addbyid FROM consumer AS c LEFT JOIN users AS u ON c.added_by=u.id WHERE c.date BETWEEN date_sub(now(),INTERVAL 1 WEEK) and now() LIMIT 6");
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $rows[] = $row;
            }
            return $rows;
        }
    } catch (\Throwable $th) {
        file_put_contents("log.txt", file_get_contents("log.txt") . "\n" . $th);
        return false;
    }
}

function getConsumer($q, $equal = false, $useid = false) {
    $conn = conn();
    if ($equal) {
        $query = "SELECT * FROM consumer WHERE `name` = ? OR `phone_number` = ? LIMIT 1";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ss", $q, $q);
    } elseif ($useid) {
        $query = "SELECT * FROM consumer WHERE `id` = ? LIMIT 1";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $q);
    } else {
        $query = "SELECT * FROM consumer WHERE `name` LIKE ? OR `phone_number` LIKE ?";
        $q = str_replace(" ", "%", "%" . $q . "%");
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ss", $q, $q);
    }

    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $rows[] = $row;
        }
        return $rows;
    }
    return false;
}

function getConsumerWithAddBy($q) {
    $conn = conn();

    $query = "SELECT c.id, c.name, c.address, c.date, u.name as addby, u.id as addbyid FROM consumer AS c LEFT JOIN users AS u ON c.added_by=u.id WHERE c.name LIKE ? OR c.phone_number LIKE ?";
    $q = str_replace(" ", "%", "%" . $q . "%");
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ss", $q, $q);


    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $rows[] = $row;
        }
        return $rows;
    }
    return false;
}

function isPhoneNumber($phone_number) {
    $re = '/[0]{1}[7]{1}[0-9]{9}/m';
    if (preg_match($re, $phone_number)) {
        return true;
    } else {
        return false;
    }
}

function addNewProduct($product) {
    try {
        if (empty(@$product["barcodes"]) || empty(@$product["name"])) {
            return ["ok" => false, "msg" => "يجب ملء كافة الحقول", "code" => 5];
        } else {
            if (str_contains($product["barcodes"], "\r\n")) {
                $barcode = explode("\r\n", $product["barcodes"]);
                if (is_array($barcode)) {
                    if ($barcode[count($barcode) - 1] == "\r\n") {
                        unset($barcode[count($barcode) - 1]);
                    }
                    $check_exist = getProductByBarcode($barcode[0]);
                }
                $barcodes = json_encode($barcode);
            } else {
                $barcodes = $product["barcodes"];
                $check_exist = getProductByBarcode($barcodes);
            }
            // check if exist
            if ($check_exist) {
                return ["ok" => false, "msg" => "موجود مسبقاً", "code" => 6];
            }

            $conn = conn();
            $stmt = $conn->prepare("INSERT INTO `product` (`barcode`, `number`, `name`, `quantity`, `buy_price`, `sell_price`, `wholesale_price`, `class_id`, `unit_id`, `warehouse_name`, `corridor`, `shelf`, `box`, `note`, `img`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            $stmt->bind_param("sssssssssssssss", $barcodes, $product["number"], $product["name"], $product["quantity"], $product["buy_price"], $product["sell_price"], $product["wholesale_price"], $product["class_id"], $product["unit_id"], $product["warehouse_name"], $product["corridor"], $product["shelf"], $product["box"], $product["note"], $product["img"]);
            $stmt->execute();
            return ["ok" => true];
        }
    } catch (\Throwable $th) {
        file_put_contents("log.txt", file_get_contents("log.txt") . "\n" . $th);
        return false;
    }
}

function updateProduct($product) {
    try {
        if (empty(@$product["barcodes"]) || empty(@$product["name"])) {
            return ["ok" => false, "msg" => "يجب ملء كافة الحقول", "code" => 5];
        } else {
            if (str_contains($product["barcodes"], "\r\n")) {
                $barcode = explode("\r\n", $product["barcodes"]);
                if (is_array($barcode)) {
                    if ($barcode[count($barcode) - 1] == "\r\n") {
                        unset($barcode[count($barcode) - 1]);
                    }
                    $check_exist = getProductByBarcode($barcode[0]);
                }
                $barcodes = json_encode($barcode);
            } else {
                $barcodes = $product["barcodes"];
                $check_exist = getProductByBarcode($barcodes);
            }
            // check if exist
            if (!$check_exist) {
                return ["ok" => false, "msg" => "لا يمكن تحديث منتج غير موجود بقاعدة البيانات"];
            }

            $conn = conn();
            $stmt = $conn->prepare("UPDATE `product` SET `barcode` = ?, `number` = ?, `name` = ?, `quantity` = ?, `buy_price` = ?, `sell_price` = ?, `wholesale_price` = ?, `class_id` = ?, `unit_id` = ?, `warehouse_name` = ?, `corridor` = ?, `shelf` = ?, `box` = ?, `note` = ?, `img` = ? WHERE id = ?");
            $stmt->bind_param("ssssssssssssssss", $barcodes, $product["number"], $product["name"], $product["quantity"], $product["buy_price"], $product["sell_price"], $product["wholesale_price"], $product["class_id"], $product["unit_id"], $product["warehouse_name"], $product["corridor"], $product["shelf"], $product["box"], $product["note"], $product["img"], $product["id"]);
            if ($stmt->execute()) {
                return ["ok" => true];
            } else {
                return ["ok" => false, "msg" => "خطأ داخلي"];
            }
        }
    } catch (\Throwable $th) {
        file_put_contents("log.txt", file_get_contents("log.txt") . "\n" . $th);
        return false;
    }
}

function addNewUser($username, $password, $name, $isAdmin) {
    try {
        if (empty($name) || empty($username) || empty($password)) {
            return ["ok" => false, "msg" => "يجب ملء كافة الحقول", "code" => 5];
        } else {
            // check if exist
            if (getUserByUserName($username)) {
                return ["ok" => false, "msg" => "موجود مسبقاً", "code" => 6];
            }
            $conn = conn();
            $stmt = $conn->prepare("INSERT INTO `users` (`name`, `username`, `password`, `added_by`) VALUES (?,?,?,?)");
            $stmt->bind_param("ssss", $name, $username, $password, $_SESSION["user_id"]);
            if ($stmt->execute()) {
                $role = addRole("admin_panel", (($isAdmin) ? 1 : 0), getUserByUserName($username)["id"]);
                if ($role) {
                    return ["ok" => true];
                }
            }
            return ["ok" => false, "msg" => "خطأ داخلي"];
        }
    } catch (\Throwable $th) {
        file_put_contents("log.txt", file_get_contents("log.txt") . "\n" . $th);
        return false;
    }
}

function updateUserData($username, $password, $name, $id, $isAdmin) {
    try {
        if (empty($name) || empty($username) || empty($password) || empty($id)) {
            return ["ok" => false, "msg" => "يجب ملء كافة الحقول", "code" => 5];
        } else {
            // check if exist
            if (!getUserByID($id)) {
                return ["ok" => false, "msg" => "لايمكن تحديث معلومات هذا الموظف"];
            }
            $role = updateRole("admin_panel", (($isAdmin == 'on') ? 1 : 0), $id);
            $conn = conn();
            $stmt = $conn->prepare("UPDATE `users` SET `name` = ?, `username` = ?, `password` = ? WHERE id = ?");
            $stmt->bind_param("ssss", $name, $username, $password, $id);
            if ($stmt->execute() && $role) {
                return ["ok" => true];
            } else {
                return ["ok" => false, "msg" => "خطأ داخلي"];
            }
        }
    } catch (\Throwable $th) {
        file_put_contents("log.txt", file_get_contents("log.txt") . "\n" . $th);
        return false;
    }
}

function addNewConsumer($name, $phone_number, $address, $notes) {
    try {
        if (empty($name) || empty($phone_number) || empty($address)) {
            return ["ok" => false, "msg" => "يجب ملء كافة الحقول", "code" => 5];
        } else {
            if (!isPhoneNumber($phone_number)) {
                return ["ok" => false, "msg" => "ادخل رقم هاتف صحيح", "code" => 5];
            }
            // check if exist
            if (getConsumer($name, true) || getConsumer($phone_number, true)) {
                return ["ok" => false, "msg" => "العميل موجود مسبقاً", "code" => 6];
            }
            $conn = conn();
            $stmt = $conn->prepare("INSERT INTO `consumer` (`name`, `phone_number`, `address`, `notes`, `added_by`) VALUES (?,?,?,?,?)");
            $stmt->bind_param("sssss", $name, $phone_number, $address, $notes, $_SESSION["user_id"]);
            if ($stmt->execute()) {
                return getConsumer($phone_number, true);
            } else {
                return ["ok" => false, "msg" => "حدث خطا من السيرفر رقم الخطا 3485"];
            }
        }
    } catch (\Throwable $th) {
        file_put_contents("log.txt", file_get_contents("log.txt") . "\n" . $th);
        return false;
    }
}

function updateConsumer($id, $name, $phone_number, $address, $notes) {
    try {
        if (empty($name) || empty($phone_number) || empty($address)) {
            return ["ok" => false, "msg" => "يجب ملء كافة الحقول", "code" => 5];
        } else {
            if (!isPhoneNumber($phone_number)) {
                return ["ok" => false, "msg" => "ادخل رقم هاتف صحيح", "code" => 5];
            }
            $conn = conn();
            $stmt = $conn->prepare("UPDATE `consumer` SET `name` = ?, `phone_number` = ?, `address` = ?, `notes` = ? WHERE id = ?");
            $stmt->bind_param("sssss", $name, $phone_number, $address, $notes, $id);
            $stmt->execute();
            return ["ok" => true];
        }
    } catch (\Throwable $th) {
        file_put_contents("log.txt", file_get_contents("log.txt") . "\n" . $th);
        return false;
    }
}



function deleteOrder($order_id) {
    $conn = conn();
    $stmt = $conn->prepare("DELETE FROM `orders` WHERE `order_id` = ?");
    $stmt->bind_param("i", $order_id);
    if($stmt->execute()){
        $stmt->close();
        $stmt = $conn->prepare("DELETE FROM `order_detail` WHERE `order_id` = ?");
        $stmt->bind_param("i", $order_id);
        $stmt->execute();
        $stmt->close();
        return true;
    }
    return false;
}
function saveOrder($orderDetails) {

    try {
        $conn = conn();
        if (@$orderDetails["update"] === "true") {
            deleteOrder($orderDetails["order_id"]);
        }

        $stmt = $conn->prepare("INSERT INTO `orders` (`order_id`, `employee_id`, `consumer_id`, `items_count`, `discount`, `price_paid`, `price_left`, `isitfinished`, `total_price`) VALUES (?,?,?,?,?,?,?,?,?);");
        $stmt->bind_param("iiiiiddid", $orderDetails["order_id"], $_SESSION["user_id"], $orderDetails["consumer_id"], $orderDetails["items_count"], $orderDetails["discount"], $orderDetails["price_paid"], $orderDetails["price_left"], $orderDetails["isitfinished"], $orderDetails["total_price"]);
        $stmt->execute();
        $stmt->close();
        file_put_contents("data.txt", "INSERT INTO `orders` (`order_id`, `employee_id`, `consumer_id`, `items_count`, `discount`, `price_paid`, `price_left`, `isitfinished`, `total_price`) VALUES ($orderDetails[order_id], $_SESSION[user_id], $orderDetails[consumer_id], $orderDetails[items_count], $orderDetails[discount], $orderDetails[price_paid], $orderDetails[price_left], $orderDetails[isitfinished], $orderDetails[total_price])");
        $items = $orderDetails["items"];
        foreach ($items as $key => $value) {
            $stmt = $conn->prepare("INSERT INTO `order_detail` (`order_id`, `product_id`, `prodect_barcode`, `quantity`, `sold_price`) VALUES (?,?,?,?,?)");
            $stmt->bind_param("iiiid", $orderDetails["order_id"], $value[3], $value[0], $value[1], $value[2]);
            $stmt->execute();
            $stmt->close();
            $stmt = $conn->prepare("UPDATE `product` SET `quantity` = `quantity` - ? WHERE `id` = ?");
            $stmt->bind_param("ii", $value[1], $value[3]);
            $stmt->execute();
            $stmt->close();
        }

        return true;
    } catch (\Throwable $th) {
        file_put_contents("log.txt", file_get_contents("log.txt") . "\n" . $th);
        return false;
    }
}

/* ---------- Delete Items ---------- */

function deleteProduct($id) {
}

function deleteItem($type, $id) {
    $typesArr = [
        "product" => "product",
        "client" => "consumer",
        "user" => "users",
        "unit" => "unit",
        "class" => "class",
    ];
    if (key_exists($type, $typesArr)) {
        $conn = conn();
        $stmt = $conn->prepare("DELETE FROM $typesArr[$type] WHERE `id` = ?");
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            return "تم الحذف بنجاح";
        } else {
            return false;
        }
    } else {
        return false;
    }
}

/* ---------- Delete Items ---------- */

/* ---------- Units And Classes ---------- */

#ADD NEW
function addNewUnit($type) {
    $conn = conn();
    $stmt = $conn->prepare("INSERT INTO `unit` (`type`) VALUES (?)");
    $stmt->bind_param("s", $type);
    if ($stmt->execute()) {
        return "تم اضافة الوحدة '$type' بنجاح!";
    } else {
        return false;
    }
}

function addNewClass($type) {
    $conn = conn();
    $stmt = $conn->prepare("INSERT INTO `class` (`type`) VALUES (?)");
    $stmt->bind_param("s", $type);
    if ($stmt->execute()) {
        return "تم اضافة النوع '$type' بنجاح!";
    } else {
        return false;
    }
}

# GET LIST
function getUnitsList() {
    $conn = conn();
    $stmt = $conn->prepare("SELECT u.id AS unitID, u.type AS unitType FROM unit AS u");
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $rows[] = $row;
        }
        return $rows;
    }
    return false;
}

function getClassesList() {
    $conn = conn();
    $stmt = $conn->prepare("SELECT c.id AS classID, c.type AS classType FROM class AS c");
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $rows[] = $row;
        }
        return $rows;
    }
    return false;
}

#UPDATE
function updateUnit($type, $id) {
    if (empty($type) || empty($id)) {
        return ["ok" => false, "msg" => "يجب ملء كافة الحقول", "code" => 5];
    } else {
        if (!getUnitByID($id)) {
            return ["ok" => false, "msg" => "لايمكن تحديث هذا العنصر"];
        }
        $conn = conn();
        $stmt = $conn->prepare("UPDATE `unit` SET `type` = ? WHERE id = ?");
        $stmt->bind_param("ss", $type, $id);
        if ($stmt->execute()) {
            return ["ok" => true];
        } else {
            return false;
        }
    }
}

function updateClass($type, $id) {
    if (empty($type) || empty($id)) {
        return ["ok" => false, "msg" => "يجب ملء كافة الحقول", "code" => 5];
    } else {
        if (!getClassByID($id)) {
            return ["ok" => false, "msg" => "لايمكن تحديث هذا العنصر"];
        }
        $conn = conn();
        $stmt = $conn->prepare("UPDATE `class` SET `type` = ? WHERE id = ?");
        $stmt->bind_param("ss", $type, $id);
        if ($stmt->execute()) {
            return ["ok" => true];
        } else {
            return false;
        }
    }
}

/* ---------- Units And Classes ---------- */



function updateSetting($var, $val) {
    $conn = conn();
    $stmt = $conn->prepare("UPDATE `sittings` SET `value` = ? WHERE `sittings`.`variable` = ?");
    $stmt->bind_param("ss", $val, $var);
    if ($stmt->execute()) {
        return true;
    } else {
        return false;
    }
}

function change_my_pass($newPass) {
    $conn = conn();
    $stmt = $conn->prepare("UPDATE `users` SET `password` = ? WHERE `id` = ?");
    $stmt->bind_param("si", $newPass, $_SESSION["user_id"]);
    if ($stmt->execute()) {
        return true;
    } else {
        return false;
    }
}



/* ---------- Printers ---------- */
function getPrinterProperty($key){
    $str = shell_exec('wmic printer get '.$key.' /value');
    $keys = explode(', ',$key);
    $validValues = [];
    $fragments = explode(PHP_EOL,$str);
    foreach($fragments as $fragment){
        if($fragment == ""){
            continue;
        }
        foreach($keys as $keyname){
            if (preg_match('/('.$keyname."=".')/i', $fragment)) {
                $validValues[$keyname][] = str_replace($keyname."=","",$fragment);
            }
        }
    }
    return $validValues;
} 

function addAvailablePrintersToDB(){
    $resp = getPrinterProperty("Name");
    $result = "('" . implode("'), ('", $resp['Name']) . "')";

    $conn = conn();
    $stmt = $conn->prepare("INSERT INTO `printers` (`PrinterName`) VALUES" . $result);
    if ($stmt->execute()) {
        return true;
    } else {
        return false;
    }
}


/* ---------- Back up ---------- */

function getBackUp(){
    // Get connection object and set the charset
    $conn = conn();
    $conn->set_charset("utf8");
    
    
    // Get All Table Names From the Database
    $tables = array();
    $sql = "SHOW TABLES";
    $result = mysqli_query($conn, $sql);
    
    while ($row = mysqli_fetch_row($result)) {
        $tables[] = $row[0];
    }
    
    $sqlScript = "";
    foreach ($tables as $table) {
        
        // // Prepare SQLscript for creating table structure
        // $query = "SHOW CREATE TABLE $table";
        // $result = mysqli_query($conn, $query);
        // $row = mysqli_fetch_row($result);
        
        // $sqlScript .= "\n\n" . $row[1] . ";\n\n";
        
        
        $query = "SELECT * FROM $table";
        $result = mysqli_query($conn, $query);
        
        $columnCount = mysqli_num_fields($result);
        
        // Prepare SQLscript for dumping data for each table
        for ($i = 0; $i < $columnCount; $i ++) {
            while ($row = mysqli_fetch_row($result)) {
                $sqlScript .= "INSERT IGNORE INTO $table VALUES(";
                for ($j = 0; $j < $columnCount; $j ++) {
                    $row[$j] = $row[$j];
                    
                    if (isset($row[$j])) {
                        $sqlScript .= '"' . $row[$j] . '"';
                    } else {
                        $sqlScript .= '""';
                    }
                    if ($j < ($columnCount - 1)) {
                        $sqlScript .= ',';
                    }
                }
                $sqlScript .= ");\n";
            }
        }
        
        $sqlScript .= "\n"; 
    }
    
    
    // Save It As File
    // if(!empty($sqlScript))
    // {
    //     // Save the SQL script to a backup file
    //     $backup_file_name = $database_name . '_backup_' . time() . '.sql';
    //     $fileHandler = fopen($backup_file_name, 'w+');
    //     $number_of_lines = fwrite($fileHandler, $sqlScript);
    //     fclose($fileHandler); 
    
    //     // Download the SQL backup file to the browser
    //     header('Content-Description: File Transfer');
    //     header('Content-Type: application/octet-stream');
    //     header('Content-Disposition: attachment; filename=' . basename($backup_file_name));
    //     header('Content-Transfer-Encoding: binary');
    //     header('Expires: 0');
    //     header('Cache-Control: must-revalidate');
    //     header('Pragma: public');
    //     header('Content-Length: ' . filesize($backup_file_name));
    //     ob_clean();
    //     flush();
    //     readfile($backup_file_name);
    //     exec('rm ' . $backup_file_name); 
    // }
    return $sqlScript;
}


/* ---------- Restore ---------- */

function restoreMysqlDB($filePath, $conn){
    $sql = '';
    $error = '';
    
    if (file_exists($filePath)) {
        $lines = file($filePath);
        
        foreach ($lines as $line) {
            
            // Ignoring comments from the SQL script
            if (substr($line, 0, 2) == '--' || $line == '') {
                continue;
            }
            
            $sql .= $line;
            
            if (substr(trim($line), - 1, 1) == ';') {
                $result = mysqli_query($conn, $sql);
                if (! $result) {
                    $error .= mysqli_error($conn) . "\n";
                }
                $sql = '';
            }
        } // end foreach
        
        if ($error) {
            trigger_error($error);
            return false;
        } else {
            return true;
        }
    }
}

