<?php




function checkUpdate($update = false) {

    include_once 'config.php';

    // From URL to get webpage contents.
    $url = $flex['update_link'];

    // Get version number and update URL
    $values = json_decode(file_get_contents($url), true);

    if($values["version"] > $flex['version']) {
        if($update == true){
            // assuming file.zip is in the same directory as the executing script.
            $file = "update.zip";

            // Download the zip file that contains the new version
            file_put_contents($file, file_get_contents($values["zip"]));

            // get the absolute path to $file
            $path = pathinfo(realpath($file), PATHINFO_DIRNAME);

            $zip = new ZipArchive;
            $res = $zip->open($file);
            if ($res === TRUE) {
                // extract it to the path we determined above
                $zip->extractTo($path);
                $zip->close();
                unlink($file);
                return ["ok" => true, 1]; // Flex has been extracted successfully
            } else {
                return ["ok" => false, 2]; // Flex has not been extracted successfully
            }
        }else{
            return ["ok" => true, 3]; // "There is a new version"
        }
    }else{
        return ["ok" => false, 4]; //"There isn't a new version"
    }
}


if(@$_POST["check"] == 1){
    echo json_encode(checkUpdate(@$_POST["update"] ?? false));
}