<div class="h-screen flex-grow-1">
    <!-- Header -->
    <header class="bg-surface-primary border-bottom pt-6">
        <div class="container-fluid">
            <div class="mb-npx">
                <div class="row align-items-center">
                    <div class="col-sm-6 col-12 mb-4 mb-sm-0">
                        <!-- Title -->
                        <h1 class="h2 mb-6 ls-tight">الاعدادات</h1>
                    </div>
                    <!-- Actions -->
                    <div class="col-sm-6 col-12 text-sm-end">
                        <div class="mx-n1">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- Main -->
    <main class="py-6 bg-surface-secondary">
        <div class="container-fluid">
            <div class="card shadow border-0 mb-7">
                <div class="card-header">
                    
                </div>
                <div class="table-responsive">
                    <div class="row">
                        <div class="col">
                            <div class="row">
                                <span>الاصدار</span>
                            </div>
                            <div class="row">
                                <span>كلمة المرور لهذا الحساب</span>
                            </div>
                            <div class="row">
                                <span>رمز سعر الجملة</span>
                            </div>
                            <div class="row">
                                <span>الصورة الافتراضية للمنتجات</span>
                            </div>
                            <div class="row">
                                <span>التحديثات</span>
                            </div>
                            <div class="row">
                                <a href="?logout=1" class="btn btn-outline-danger">تسجيل الخروج</a>
                            </div>
                            <input type="hidden" name="defult_product_img" id="defult_product_img">
                        </div>
                        <div class="col">
                            <div class="row">
                                <span><?php echo $flex["version"]; ?></span>
                            </div>
                            <div class="row">
                                <input class="form-control" id="change_my_password" type="password" value="just some text here">
                            </div>
                            <div class="row">
                                <input class="form-control" id="change_wholesale_password" type="password" value="just some text here">
                            </div>
                            <div class="row">
                                <div class="col">
                                    <div class="row">
                                        <img class="img-fluid rounded d-block" id="product_img">
                                    </div>
                                    <div class="row">
                                        <input class="form-control form-control-sm" type="file" id="imgInput" accept="image/*">
                                        <canvas height="300" width="400" style="display: none;" id="product_canvas">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col">
                                    <button id="checkupdate" class="btn btn-secondary form-control">الكشف عن التحديثات</button>
                                </div>
                                <div class="col">
                                    <button id="updatenow" class="btn btn-primary form-control" style="display: none;">التحديث الان</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-footer border-0 py-5">
                </div>
            </div>
        </div>
    </main>
</div>


<script>

    function drawImageScaled(img, ctx) {
        var canvas = ctx.canvas;
        var hRatio = canvas.width / img.width;
        var vRatio = canvas.height / img.height;
        var ratio = Math.min(hRatio, vRatio);
        var centerShift_x = (canvas.width - img.width * ratio) / 2;
        var centerShift_y = (canvas.height - img.height * ratio) / 2;
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(img, 0, 0, img.width, img.height, centerShift_x, centerShift_y, img.width * ratio, img.height * ratio);
        return canvas.toDataURL();
    }

    function updateProductImg(url) {
        canvas = $('#product_canvas');
        ctx = canvas[0].getContext('2d');
        img = new Image;
        img.onload = function() {
            data = drawImageScaled(img, ctx);
            $("#img").val(data);
            $('#product_img')[0].src = data;
        }
        img.src = url;
        $.post("", 'update_defult_product_img=' + $("#defult_product_img").val(), function (html) {
            try {
                resp = JSON.parse(html);
            } catch (error) {
                alertify.error('حدث خطا من السيرفر');
                return;
            }
            if (resp.ok == false) {
                alertify.error(resp.msg);
            } else {
                alertify.success("تم تحديث الصورة الافتراضية للمنتجات");
            }
        });
    }

    $(document).ready(function () {
        $('#imgInput').change(function () {
            updateProductImg(URL.createObjectURL($(this)[0].files[0]));
        });
        

        $("#change_wholesale_password").click(() => {
            alertify.prompt('تغيير رمز سعر الجملة', '<div dir="rtl">الرمز الجديد</div>', ''
                , function (evt, value) {
                    $.post("", 'change_wholesale_password=' + $("#change_wholesale_password").val(), function (html) {
                        try {
                            resp = JSON.parse(html);
                        } catch (error) {
                            alertify.error('حدث خطا من السيرفر');
                            return;
                        }
                        if (resp.ok == false) {
                            alertify.error(resp.msg);
                        } else {
                            alertify.success("تم تحديث رمز سعر الجملة");
                        }
                    });
                }
                , function () { alertify.error('تم الالغاء') });
        });
        
        $("#change_my_password").click(() => {
            alertify.prompt('تغيير رمز الحساب', '<div dir="rtl">الرمز الجديد</div>', ''
                , function (evt, value) {
                    $.post("", 'change_my_password=' + $("#change_wholesale_password").val(), function (html) {
                        try {
                            resp = JSON.parse(html);
                        } catch (error) {
                            alertify.error('حدث خطا من السيرفر');
                            return;
                        }
                        if (resp.ok == false) {
                            alertify.error(resp.msg);
                        } else {
                            alertify.success("تم تحديث رمز الحساب");
                        }
                    });
                }
                , function () { alertify.error('تم الالغاء') });
        });
        
        $("#checkupdate").click(() => {
            $.post("update.php", 'check=1&update=1', function (html) {
                try {
                    resp = JSON.parse(html);
                } catch (error) {
                    alertify.error('حدث خطا من السيرفر');
                    return;
                }
                if (resp.ok == false) {
                    if(resp[0] == 4){
                        alertify.error("لا يوجد تحديث جديد");
                    }
                } else {
                    if(resp[0] == 3){
                        alertify.success("يوجد تحديث جديد ");
                        $("#updatenow").show();
                    }
                }
            });
        });
        function wait(ms){
            var start = new Date().getTime();
            var end = start;
            while(end < start + ms) {
              end = new Date().getTime();
           }
         }
        $("#updatenow").click(() => {
            $.post("update.php", 'check=1&update=2', function (html) {
                try {
                    resp = JSON.parse(html);
                } catch (error) {
                    alertify.error('حدث خطا من السيرفر');
                    return;
                }
                if (resp.ok == false) {
                    if(resp[0] == 2){
                        alertify.error("حدثت مشكلة اثناء محاولة التحديث");
                    }
                } else {
                    if(resp[0] == 1){
                        alertify.success("تم التحديث بنجاح");
                        wait(2000);
                        window.location.reload();
                    }
                }
            });
        });
    });
</script>